﻿ 最简单的基于FFmpeg的内存读写例子（内存播放器）
 Simplest FFmpeg mem Player

 雷霄骅
 leixiaohua1020@126.com
 中国传媒大学/数字电视技术
 Communication University of China / Digital TV Technology
 http://blog.csdn.net/leixiaohua1020

 本程序实现了对内存中的视频数据的播放。
 是最简单的使用FFmpeg读内存的例子。

 This software play video data in memory (not a file).
 It's the simplest example to use FFmpeg to read from memory.
